<template>
	<view>
		
	</view>
</template>

<script>
	export default {
		name:"<%fileName%>",
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="stylus">

</style>
